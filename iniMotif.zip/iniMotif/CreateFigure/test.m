% e.g.
% first_dir = '/wrk/data/lu_data/testdata/testout/IniMotifOutput/';
% second_dir = '/wrk/data/lu_data/testdata/testout/SecondMotif/';
% WIDTH = 6:10;
% MODE = 'skip';

first_dir = '';
second_dir = '';
WIDTH = 6:10;
MODE = '';

drawAllBatches(first_dir, WIDTH, MODE);
drawAllBatches(second_dir, WIDTH, MODE);

% e.g.
% first_dir = '/wrk/data/lu_data/testdata/testout/IniMotifOutput/';
% second_dir = '/wrk/data/lu_data/testdata/testout/SecondMotif/';
% WIDTH = 6:10;
% MODE = 'skip';

first_dir = '/home/ji/IniMotifOutput/';
%second_dir = '';
WIDTH = 5:11;
MODE = 'normal';
FIGURE_TYPE = 'png';

%drawAllBatches(first_dir, WIDTH, MODE);
drawAllBatches(first_dir, WIDTH, MODE, FIGURE_TYPE);
%drawAllBatches(second_dir, WIDTH, MODE);

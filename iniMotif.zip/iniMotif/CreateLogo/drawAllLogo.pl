#!/usr/bin/perl -w

use strict;
use warnings;

use File::Find;
use TFBS::Matrix::PFM;

# this script locates all motif files under the root directory
# then draw logos for motifs in the logo directory
# Lu Cheng, lu.cheng.cs@gmail.com
# 28.09.2009

# skip mode has been added
# Lu Cheng, lu.cheng.cs@gmail.com
# 06.10.2009

# empty motif files will not be processed
# Lu Cheng
# 19.10.2009

# input parameters
if(scalar(@ARGV) < 3){
	print "Please input the mode (-NORMAL|-REVCOM), program (drawAllLogo) direcory, root directory of IniMotif output (include sourcedata)\n";
	exit 0;
}

# current directory (drawAllLogo), program directory (drawAllLogo), IniMotif output directory (include IniMotifOutput, Secondary)
my $mode = $ARGV[0];
my $proc_dir = $ARGV[1];
my $root_dir = $ARGV[2];
my $skip_mode = $ARGV[3];

if($skip_mode eq "skip"){
  $skip_mode = 1;
}else{
  $skip_mode = 0;
}

$proc_dir =~ s/^(.+)(\/*)$/$1\//;
$root_dir =~ s/^(.+)(\/*)$/$1\//;  # add a '/' to the end of the dir

	#############################
	chdir($proc_dir);
	find(\&produceLogo,$root_dir);

############################################################################
sub produceLogo() {

	if(-f and /.pwm/) {
 		my $file = $_;

		#print "$File::Find::dir $file\n";
		my $out_file = $file;
		$out_file =~ s/\.pwm$//;
		$out_file = $out_file.".png";

		my $title = "";
		my $matrix_ref = "";
		
		open(MOTIF,"$file");
		my @motif = <MOTIF>;
		close(MOTIF);
		
		# quit if the file is empty
		unless(scalar(@motif)){
		  return;
		}

		my @values;
		my $line;
		for(my $i=0; $i<scalar(@motif); $i++){
			chomp($motif[$i]);
			if($motif[$i] eq "Final Motif for logo"){
				for(my $j=1 ; $j<5; $j++){

				        $line = $motif[$i+$j];
					chomp($line);

					@values = split(/\t/, $line);
					shift(@values);
					$line = join("\t", @values);

					$matrix_ref = join("",$matrix_ref,$line,"\n");
				}
				last;
			}
		}

		$title = $motif[0];
		
		unless(-d "../logo"){
		  system("mkdir ../logo")==0 or die "mkdir ../logo failed: $?";
		}
		$out_file = join("","../logo/",$out_file);
		
		if($skip_mode==1 && -f $out_file){
		  return;
		}

		drawLogo($mode, $title, $matrix_ref, $out_file);

	}
}


##################################################################################################333333###3333#333333
sub drawLogo{

  my ($mode, $title, $matrix_ref, $out_file) = @_;

  if($mode eq "-NORMAL"){
    # do nothing
  }elsif($mode eq "-REVCOM"){
    $matrix_ref = RevCom($matrix_ref);
  }else{
    print "Please input the mode(-NORMAL|-REVCOM) , logo title, motif(PSSM) and file name for the logo!\n";
    exit 0;
  }

  my $icm = TFBS::Matrix::ICM->new(-matrixstring => $matrix_ref,
				   -name   => "",
				   -ID     => ""
			          );


  $icm->draw_logo(-file=> $out_file,
                 -full_scale => 2.25,
		 -xsize => 400,
		 -ysize => 200,
		 -graph_title=> $title,
		 -x_title=>"position",
		 -y_title=>"bits");
}

sub RevCom{
	my ($str) = @_;

	my @mat_rows = split(/\n+/,$str);
	my @tmp = ();

	for(my $i=0; $i<scalar(@mat_rows); $i++){
		next if $mat_rows[$i] =~ /^\s*$/;   #skip blank lines
		@tmp = split(/\t+/,$mat_rows[$i]);
		@tmp = reverse(@tmp);
		$mat_rows[$i] = join("\t",@tmp);
	}
	
	@mat_rows = reverse(@mat_rows);
	my $ret = join("\n",@mat_rows);
	$ret =~ s/\n+/\n/g;
	return $ret;	
}

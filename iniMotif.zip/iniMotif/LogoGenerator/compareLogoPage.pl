#!/usr/bin/perl -w

use strict;
use warnings;

my $page_name = $ARGV[0];
my $logo_dir1 = $ARGV[1];
my $logo_dir2 = $ARGV[2];
my $logo_dir3 = $ARGV[3];

$logo_dir1 =~ s/\/$//;
$logo_dir2 =~ s/\/$//;
$logo_dir3 =~ s/\/$//;

open(TEMPLATE,"PAGE_TEMPLATE.html");
my @template = <TEMPLATE>;
close(TEMPLATE);

opendir(DIR, "$logo_dir1");
my @files = grep { !/^\.\.?/ } readdir(DIR);
closedir(DIR);

my @table = ();
foreach (@files){
  push(@table, "<tr>\n");

  push(@table, "<td>\n");
  push(@table,"$_\n");
  push(@table, "</td>\n");

  push(@table, "<td>\n");
  push(@table,"<img src = \"$logo_dir1/$_\" class=\"logo\">\n");
  push(@table, "</td>\n");

  push(@table, "<td>\n");
  push(@table,"<img src = \"$logo_dir2/$_\" class=\"logo\">\n");
  push(@table, "</td>\n");

  push(@table, "<td>\n");
  push(@table,"<img src = \"$logo_dir3/$_\" class=\"logo\">\n");
  push(@table, "</td>\n");

  push(@table, "</tr>\n");
}


open(PAGE, ">$page_name");
my $line;
foreach $line (@template){
  if($line =~ /INSERT_SECTION!/){
    foreach(@table){
      print PAGE $_;
    }
  }else{
    print PAGE $line;
  }
}



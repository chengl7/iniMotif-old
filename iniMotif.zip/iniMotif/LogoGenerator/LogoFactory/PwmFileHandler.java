package LogoFactory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;

public abstract class PwmFileHandler {
	public String FileName;
	
	private double[] BackDis = {0.25, 0.25, 0.25, 0.25};
	private double[][] pfm;
	private double[][] LogoMat;
	private double[][] InfoMat; // information content matrix
	
	private double[] InfoVector;
	
	public PwmFileHandler(String _FileName) {
		this.FileName = _FileName;
	}
	
	private String mat2str(double[][] mat) {
		int rows = 4;
		int cols = mat[0].length;
		
		NumberFormat nf = NumberFormat.getNumberInstance(Locale.CHINA);
		nf.setMaximumFractionDigits(3);
		
		String str = "";
		for(int i=0; i<rows; i++){
			for(int j=0; j<cols; j++){
				if(j==cols-1){
					str += nf.format(mat[i][j]) + "\n";
				}else{
					str += nf.format(mat[i][j]) + "\t";
				}
			}
		}
		
		return str;
	}
	
	private void calMotif(){
		// ensure the position frequency matrix is normalized
		pfm = normalize(pfm);
		
		// calculate information content based matrix
		int WIDTH = pfm[0].length;
		InfoMat = new double[4][WIDTH];
		LogoMat = new double[4][WIDTH];
		InfoVector = new double[WIDTH];
		for(int i=0; i<4; i++){
			for(int j=0; j<WIDTH; j++){
				InfoMat[i][j] = Math.log(pfm[i][j]/BackDis[i])/Math.log(2) * pfm[i][j] ; 
			}
		}
		
		for(int j=0; j<WIDTH; j++){
			double sum = 0;
			for(int i=0; i<4; i++){
				sum += InfoMat[i][j];
			}
			
			InfoVector[j] = sum;
			
			for(int k=0; k<4; k++){
				LogoMat[k][j] = pfm[k][j] * sum;
			}
		}
	}
	
	public String getLogoMatrix(){
		pfm = getPFM();
		
		calMotif();
		
		return mat2str(LogoMat);
	}
	
	public String getTrimLogoMatrix(int coreLength, double cutoff){
		pfm = getPFM();
		
		calMotif();
		
		pfm = trimFlank(coreLength, cutoff);
		
		calMotif();
		
		return mat2str(LogoMat);
		
	}
	
	public String getTrimLogoMatrix(double cutoff){
		pfm = getPFM();
		
		calMotif();
		
		pfm = trimFlank(cutoff);
		
		if(pfm==null){
			return null;
		}
		
		calMotif();
		
		return mat2str(LogoMat);
		
	}
	
	void outPFM(String outfile){
		try{
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File(outfile)));
			bw.write(mat2str(pfm));
			bw.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	private double[][] normalize(double[][] mat) {
		int WIDTH = mat[0].length;
		
		double[] sum = new double[WIDTH];
		for(int i=0; i<WIDTH; i++){
			for(int j=0; j<4; j++){
				sum[i] += mat[j][i];
			}
		}
		
		for(int i=0; i<WIDTH; i++){
			for(int j=0; j<4; j++){
				mat[j][i] = mat[j][i]/sum[i] + Double.MIN_VALUE;
			}
		}
		
		return mat;
	}
	
	// this function eliminate low information sites in the flanks
	public double[][] trimFlank(double cutoff){
		int start = 0;
		int end = InfoVector.length-1;
		
		for(int i=0; i<InfoVector.length; i++){
			if(InfoVector[i]>=cutoff){
				start = i;
				break;
			}
		}
		
		for(int i=InfoVector.length; i>0; i--){
			if(InfoVector[i-1]>cutoff){
				end = i;
				break;
			}
		}
		
		if(end<=start){
			return null;
		}else{
			double[][] trimedMatrix = new double[4][end-start];
			for(int j=start; j<end; j++){
				for(int i=0; i<4; i++){
					trimedMatrix[i][j-start] = pfm[i][j]; 
				}
			}
			return trimedMatrix;
		}
	}
	
	
	// trim the flank low information part of the given motif
	public double[][] trimFlank(int coreLength, double cutoff){

		int corePos = getCorePos(coreLength, LogoMat);
		
		if(corePos==-1){
			return pfm;
		}
		
		int start = corePos;
		int end = corePos+coreLength;
		boolean flag = true;
		while(flag){
			if(start<0 || end>=InfoMat[0].length){
				flag = false;
				continue;
			}
			
			double beforeStartInfo = -10;
			double afterEndInfo = -10;
			
			if(start-1>=0){
				beforeStartInfo = InfoVector[start-1];
			}
			
			if(end+1<InfoVector.length){
				afterEndInfo = InfoVector[end+1];
			}
			
			int new_start = start;
			int new_end = end;
			double tmpInfo;
			if(beforeStartInfo > afterEndInfo){
				new_start = start-1;
				tmpInfo = beforeStartInfo;
			}else{
				new_end = end + 1;
				tmpInfo = afterEndInfo;
			}
			
//			if(avgRemain(InfoVector,new_start,new_end)<cutoff){
			if(tmpInfo<cutoff){
				flag = false;
				continue;
			}else{
				start = new_start;
				end = new_end;
			}
		}
		
		double[][] newPFM = new double[4][end-start];
		for(int i=0; i<4; i++){
			for(int j=0;j<end-start;j++){
				newPFM[i][j] = pfm[i][start+j];
			}
		}
		
		return newPFM;
	}
	
	private double avgRemain(double[] array, int start, int end){
		double sum = 0;
		for(int i=0; i<start; i++){
			sum += array[i];
		}
		for(int i=end; i<array.length; i++){
			sum += array[i];
		}
		return sum/(array.length-end+start);
	}
	
	private int getCorePos(int coreLength, double[][] logo_mat) {
		int LEN = logo_mat[0].length;
		
		if(coreLength>LEN){
			return -1;
		}
		
		double[] InfoMat = new double[LEN];
		double[] InfoSum = new double[LEN - coreLength +1];
		for(int j=0; j<LEN; j++){
			for(int i=0; i<4; i++){
				InfoMat[j] += logo_mat[i][j]; 
			}
		}
		
		for(int j=0; j<coreLength; j++){
			InfoSum[0] += InfoMat[j];
		}
		
		double maxInfo = InfoSum[0];
		int maxPos = 0;
		for(int j=1; j<InfoSum.length; j++){
			InfoSum[j] = InfoSum[j-1] + InfoMat[j+coreLength-1] - InfoMat[j-1];
			if(InfoSum[j]>maxInfo){
				maxInfo = InfoSum[j];
				maxPos = j;
			}
		}
		
		return maxPos;
	}
	
	// the elements are supposed to be separated by tab
	public abstract double[][] getPFM();
	
}

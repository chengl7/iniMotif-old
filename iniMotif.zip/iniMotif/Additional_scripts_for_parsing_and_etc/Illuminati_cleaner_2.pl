#!/usr/local/bin/perl
use warnings;
use strict;

 #initialize stuff
##################
my $fileename = $ARGV[0];
open(FILEENAME, $fileename) or die "Cannot open the input file: \n $!";
my $row_amount = $ARGV[1];
my $qualitythreshold = $ARGV[2];
my $outputfile = $fileename . "_cleaned_with-$qualitythreshold.txt"; #makes the generic output name (of all nucleotide seq.)
my $readrows;
$readrows = $row_amount;
my $line;
my $f = $ARGV[0];
my $linecount = "0";
open (TXT,"$f");
seek (TXT,0,0);
while ($line = <TXT>) {# goes through the file once and get's total linenumber
$linecount++;
}
print "total lines - $linecount\t analyzed - $row_amount\n";
close (TXT);
if ($row_amount > $linecount){# sees whether the total linenumber is actually smaller than what was asked for
$readrows = $linecount;
}
my $failedreads =0;

#########################################################
unless ( open(OUTPUTROWS, "+>$outputfile") ) {
       #checks whether the generic outputfile works and opens the path to it
    print "Cannot open file \"$outputfile\" to write to!!\n\n";
    exit;        #checks the ooutput for generic seq.
   }
my $numberofsequences = $readrows/4;
print "Total number of sequences  -  $numberofsequences\n";
 for (my $i = 0; $i < $numberofsequences; ++$i)  {
    my $reads1 = <FILEENAME>;
    	my $reads2 = <FILEENAME>;
    	  	my $reads3 = <FILEENAME>;
    	  	  	my $reads4 = <FILEENAME>;
   if(not $reads3=~ m/^\+/) {
   print"File might be corrupt, a quality line header doesn't start with + \n";
   } 	  	  	
  
  if ($reads4=~ m/$qualitythreshold/) {#if the quality threshold doesn't pass the criterion on the regular expression
 $failedreads += 1;
   next; #Quality is set to kill all the bases within 27 first bases that go below 
   }
   print OUTPUTROWS  "$reads1$reads2$reads3$reads4";
  next;
  }
  my $percentage = int 100 * ($failedreads/$numberofsequences);
  print "Total reads failing the stringency criteria -  $failedreads\n making it $percentage percent\n";
  
 exit;
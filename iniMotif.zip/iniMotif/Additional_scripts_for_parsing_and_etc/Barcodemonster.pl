#!/usr/local/bin/perl
use warnings;
#use strict;

 #initialize stuff
##################
my $fileename = $ARGV[0];
open(FILEENAME, $fileename) or die "Cannot open the input file: \n $!";
my $row_amount = $ARGV[1];
my $filterfile = $ARGV[2];
my $targetfolder = $fileename . "_barcodes" ;  #combines filename to make the folder
mkdir $targetfolder;   #makes folder
my $outputfile = $fileename . " " . $row_amount . " - first rows output.txt"; #makes the generic output name (of all nucleotide seq.)
open (BARCODEFILTER, "$filterfile") or die "Can't open filterfile, $!";
my @filterarray = <BARCODEFILTER>;
my @names;
my @searchwords;
my @substitutes1;
my @substitutes2;
foreach (@filterarray){
  @rowow = split(/\s+/);
 push (@names, shift(@rowow));
 push (@substitutes1 , pop(@rowow));
 push (@substitutes2, pop(@rowow));
 push (@searchwords, pop(@rowow));
 }
 print @filterarray; #prints out the filterarray, I don't really know what's the point of this...
 #print @names;
 #print @searchwords;

 #tests if the file has less reads than what have been asked for, if thats the case, it'll
 #take only the asked amount
my $readrows;
$readrows = $row_amount;

my $f = $ARGV[0];
my $linecount = "0";
open (TXT,"$f");
seek (TXT,0,0);
while ($line = <TXT>) {# goes through the file once and get's total linenumber
$linecount++;
}
print $linecount;
close (TXT);
if ($row_amount > $linecount){# sees whether the total linenumber is actually smaller than what was asked for
$readrows = $linecount;
}

#########################################################
unless ( open(OUTPUTROWS, "+>$targetfolder/$outputfile") ) {
       #checks whether the generic outputfile works and opens the path to it
    print "Cannot open file \"$outputfile\" to write to!!\n\n";
    exit;        #checks the ooutput for generic seq.
   }

 for (my $i = 0; $i < $readrows; ++$i)  {
   my $reads = <FILEENAME>;
   if ($reads=~ m/^.HWU/) {#the header-files have constant part which looks like this
   next;
   }
   if ($reads=~ m/N/) {#wronly read sequence looks like this
   next;#so these two lines serve to lighten the load by stopping the computer doing heavier pattern matches to these lines
   }
     if( not $reads=~ m/^[ACTG][ACTG][ACTG][ACTG][ACTG][ACTG]/) {      #This statement makes
       next;                       # it so that the script extracts only
                                   #   the rows that are DNA - six first digits are either A, C, T or G
       }                           #

  print OUTPUTROWS $reads, ;    #prints all of the reads into one big outputrows file mark this out to make program faster...

### ####################################

for (my $o = 0; $o < scalar(@names); ++$o){
if ($reads =~ m/$searchwords[$o]/)  {#this is the trickiest part:The script does following steps for all of the lines that have passed
   $reads =~ s/$substitutes1[$o]//; #the selection you can see above.. it goes through all of the searchwords of key doing a patternmatch
   $reads =~ s/$substitutes2[$o]//; #against them. If the pattern is matched, the patterns that have been specified by key
   push (@{$names[$o]}, $reads);}  # is substituted with nothing to cut out barcodes and constant sequences
next;# you can find an example of the key-format from the end of this code (naturally without the comment marks when in the use)

}
     }
     
       close FILEENAME;

       for ($k = 0; $k < scalar(@names); $k++){
$pool_name = "$targetfolder/$names[$k].txt";
open OUTTI, "+>$pool_name" or die "Cannot open out $pool_name";
print OUTTI @{$names[$k]};
}

     # my $pool_name = ">$targetfolder/$names[0].txt";
 #open OUTTI, "+>$pool_name" or die "Cannot open out $pool_name";
 #print OUTTI @AAAAT_1;
       
    #########
#my $P = 0;

# Print the barcode pools
#for my $barcode (sort keys %barcode_pools) {
 # $P++;

 # my $pool_name = $pooldir.$barcode.".txt";
 # open OUT, ">$pool_name" or die "Cannot open out $pool_name";

  #my $n = scalar( @{ $barcode_pools{$barcode} } );
 # print OUT "# Barcode: $barcode, $n reads\n";

  #for my $randstr (sort @{ $barcode_pools{$barcode} }) {
 #   print OUT "$randstr\n";
  #}
#}


 exit;

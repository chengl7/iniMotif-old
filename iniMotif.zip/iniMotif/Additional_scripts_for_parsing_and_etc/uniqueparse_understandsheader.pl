#!/usr/local/bin/perl
#use strict;
#use warnings;


my $directoryname = $ARGV[0];   #opens parameter
my @directorhies;
chomp $directoryname;
mkdir ("$directoryname-uniqueparsed"); #makes Directory for the parsed reads
open (LOGI, "+>$directoryname-uniqueparsed/$directoryname-seqdistributions.txt")or die "cannot open logi";
opendir(DIRECTORYNAME, "$directoryname") or die "Cant open";
@directorhies = readdir DIRECTORYNAME;
close DIRECTORYNAME;
foreach (@directorhies){
if($_ =~ m/^\.*$/){next;}  #clears the . and .. thingies that all folders have
        if ($_ =~ m/.txt/){
        chomp $_;
        print LOGI "$_\t";
        open(CONTENTTI, "$directoryname/$_") or die "Won't happen";
        my @sisalto = ();
	 my $headeri = '';
        @sisalto = <CONTENTTI>;
        close CONTENTTI;
        open(FILEOUT,"+>$directoryname-uniqueparsed/$_")or die "cant do the fileout";
        foreach (@sisalto){
                chomp;
                }
		$headeri = shift @sisalto;
                my @reads = sort(@sisalto);
               unshift(@reads,$headeri);
		my $uniquecount = 0;
                my $rowamount = scalar @reads;
                print "$rowamount\n";
                my %seqspecieslist = ();
                my @newreads = "";  #makes an array for uniquefiles
                  unshift(@newreads,"$headeri\n");
              			for($i=1;$i<$rowamount;$i++){
                                if($reads[$i]ne$reads[$i-1]){
                                if($reads[$i]ne$reads[$i+1]){
                                $uniquecount++;
                                push (@newreads,"$reads[$i]\n");
                                $seqspecieslist{"$reads[$i]"} = 1;
                                 next;}}
                                $seqspecieslist{"$reads[$i]"} = ($seqspecieslist{"$reads[$i]"}+1);
                                }
                my $percentage = int(100*($uniquecount/$rowamount));
                        foreach my $key(sort keys %seqspecieslist) {
                        #print "$key = $seqspecieslist{$key}\n";
                          }
                my @avvaimet;
                my @aravot;
                my $t = 0;
                                foreach my $value (sort {$seqspecieslist{$b} <=> $seqspecieslist{$a} }keys %seqspecieslist){
                                 $t++;
                                push (@avvaimet,$seqspecieslist{$value});
                                push (@aravot, $value);
                                }
                                
                print "no. of different uniques: $uniquecount .\n";
                #print LOGI "$fileename\n";
                print LOGI "Uniques%\t$percentage\t$uniquecount\t$rowamount\t";
                print LOGI "$avvaimet[0]\t$aravot[0]\t";
                print LOGI "$avvaimet[1]\t$aravot[1]\t";
                print LOGI "$avvaimet[2]\t$aravot[2]\t";
                print LOGI "$avvaimet[3]\t$aravot[3]\t";
                print LOGI "$avvaimet[4]\t$aravot[4]\t";
                print LOGI "$avvaimet[5]\t$aravot[5]\n";
                print FILEOUT @newreads;
}
next;
}
exit;

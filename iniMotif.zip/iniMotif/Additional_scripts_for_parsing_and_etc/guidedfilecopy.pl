#!/usr/local/bin/perl
use File::Copy;
use strict;
use warnings;

my $fileename = $ARGV[0];
open (COPYLIST, $fileename) or die "Can't open filterfile, $!";
open (COPYLISTLOG, "+>$fileename-log.txt") or die "Can't open filterfile, $!";

my @commands = <COPYLIST>;
my @row = 0;
my  @oldpaths = 0;
my  @newpaths = 0;
my $rowamount = scalar @commands;
print COPYLISTLOG "$rowamount - copy operations \n Failures \n"; $rowamount;
 foreach (@commands){
  @row = split(/\s+/);
 push (@oldpaths , shift(@row));
 push (@newpaths, shift(@row));
  }
###
 my $newfile;
 my $oldfile;
print "$newpaths[1]\n";
print "$oldpaths[1]";
for(my $i=1; $i<($rowamount+1); $i++){
$newfile = "$newpaths[$i]";
$oldfile = "$oldpaths[$i]";
chomp $newfile;
chomp$oldfile;
copy($oldfile,$newfile) or print COPYLISTLOG "$oldfile to $newfile.\n";
  }

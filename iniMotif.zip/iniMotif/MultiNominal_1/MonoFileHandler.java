package MultiNominal_1;

import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

/*
 * the function of this class is to process the file
 * including header process and content process
 * Input: a file
 * Output: data structures in this class
 * 
 * If the count of the reverse complement of the consensus sequence is bigger than the count of the consensus sequence, then the reverse complement is selected as the consensus sequence
 * Lu Cheng May 29th, 2009 
 * 
 * All dir are assumed to end with "/" in this file
 * 
 * An Arraylist has been used to store the data for SubStr-HamDis figure
 * Thus Longer motifs are also computable
 * Lu Cheng Aug 17th, 2009
 * 
 */


public class MonoFileHandler {
	
	public int WIDTH;              // width of the motif 
	public int HamDisCutOff;       // cutoff of Hamming distance to the consensus sequence
	public int SeqLen;             // sequence length in the file
	public int SeqNum;	           // sequence number in the file
	
	public double NorConstant = 1;  //constant for normalize the count matrix
	public static int MAX_SEQ_NUM = 20000; // maximum number of binding sites
	public static int MIN_SEQ_NUM = 10;      // minimum line of sequences in the file
    public int ExpSubstrCount = 3;          // The expected number of a w-width substring count 
	
	public double[] BackDis;       // distribution of the four bases, include revcom
	public double[][] BindSitePosDis;      // distribution of the position for the binding sites
                                           // the first array is for binding sites on original sequences, 
                                           // while the second is for binding sites on the reverse complementary sequences  
	
	public BindSiteList BindSites;   // a list that store the least Hamming Distance substring on each sequence
	public long mask;		 //see method HandleLine()
	
	public double[][] motif;          // 4*WIDTH, information content-based weight matrix	
	public double[][] motif_pfm;      // 4*WIDTH, position frequency matrix
	
	public SeqAnalyzer SubStrTool;   // Tool for WIDTH-mer substring calculation
	public Table BarcodeTfNameTable;  // Tool for barcode consultation
	public BufferedWriter logWriter = null; //output while processing
		
	public String fileName;
    public Barcode FullBarcode;
	
    public Folder WidthFolder;
	public BufferedWriter out_hamdis;
	public BufferedWriter out_posdis;
	public BufferedWriter out_seqbias;
	public BufferedWriter out_motif;
	public BufferedWriter out_rawcount;
	
	public SeqPool InputPool;           //the pool for storing all input sequences
	public SeqPool OrigSubStrPool;
	public SeqPool SubStrPool;
	public SeqPool BindSitePool;
	
	private String CONSENSUS;
	private boolean IsProcessed;
	
	public MonoFileHandler(int width, int hamcut, int seqlen, Table bbt, BufferedWriter OutputWriter,
			String FileName, double[] backdis){
		WIDTH = width;
		HamDisCutOff = hamcut;
		SeqLen = seqlen;
		SeqNum = 0;
				
		BackDis = backdis;
		BindSitePosDis = new double[2][SeqLen-WIDTH+1];
		
		// calculate the expected number of a w-width substring
		ExpSubstrCount = calExpSubStrCount();
		BindSites = new BindSiteList(MAX_SEQ_NUM);
		
		mask = 1;
		mask = mask<<(WIDTH*2);
		mask = mask - 1;
				
		motif = new double[4][WIDTH];
		motif_pfm = new double[4][WIDTH];
		SubStrTool = new SeqAnalyzer(WIDTH);
		BarcodeTfNameTable = bbt;
		logWriter = OutputWriter;
		
		
		this.fileName = FileName;
		this.FullBarcode = new Barcode(new File(FileName).getName());
		
		this.WidthFolder = null;
		this.out_hamdis = null;
		this.out_motif = null;
		this.out_posdis = null;
		this.out_rawcount = null;
		this.out_seqbias = null;
		
		InputPool = new SeqPool(SeqLen);        // the sequence pool that stores all sequences in the input data file
		OrigSubStrPool = new SeqPool(WIDTH);    // a sequence pool that stores substrings on the the original strand in the data
		SubStrPool = new SeqPool(WIDTH);        // a sequence pool that stores substrings on both strands
		BindSitePool = new SeqPool(WIDTH);      // a sequence pool that only stores binding sites
		
		CONSENSUS = null;
		IsProcessed = false;
	}
	
	/*
	 * this method is in charge of the whole processing of the file
	 * SKIP_MODE = true, if all data files have already been generated, we will skip to handle that barcode
	 * SKIP_MODE = false, generate all data files as if they do not exist at all
	 * 
	 * The InputPool, WidthFolder, logWriter, SeqNum need to be initialized before calling this method
	 */
	private MonoFileHandler process(boolean SKIP_MODE){
		try{
			String fullbarcode = FullBarcode.getFullBarcode();
			
			out_hamdis = new BufferedWriter(new FileWriter(new File(
					WidthFolder.dir_hamdis+fullbarcode+".dat")));
			out_posdis = new BufferedWriter(new FileWriter(new File(
					WidthFolder.dir_posdis+fullbarcode+".dis")));
		    out_seqbias = new BufferedWriter(new FileWriter(new File(
		    		WidthFolder.dir_seqbias+fullbarcode+".bias")));
		    out_motif  = new BufferedWriter(new FileWriter(new File(
		    		WidthFolder.dir_motif+fullbarcode+".pwm")));
		    out_rawcount = new BufferedWriter(new FileWriter(new File(
		    		WidthFolder.dir_rawcount+fullbarcode+".cnt")));

			logWriter.write("\n"+fullbarcode+"-"+BarcodeTfNameTable.getTfName(fullbarcode)+"\n");
			
			if(SeqNum<MIN_SEQ_NUM){
				logWriter.write("only "+SeqNum+" sequences are available, so no computation.\n\n\n");
				closeDataBuffers();
				deleteDataFiles(fullbarcode);
				return null;
			}
			logWriter.write(SeqNum+" binding site are extracted.\n");
			
			// Output the sequence with the highest count in the pool
			String TopSeq = InputPool.getConsensus();
			out_posdis.write(TopSeq+"\n");
			out_posdis.write((int)InputPool.getStrCount(TopSeq)+"\n");
			out_posdis.write(InputPool.getUniqueSeqPortion()+"\n");
			
			HashMap<String, SeqPool.MyInt> tmpPool = InputPool.getPool(); 
			for(String tmpSeq : tmpPool.keySet()){
				handleLine(tmpSeq, tmpPool.get(tmpSeq).val);
			}
						
			// Get the consensus sequence
			String consensus = SubStrPool.getConsensus();
			String revcom_consensus = SubStrTool.getRevCom(consensus);
			if(OrigSubStrPool.getStrCount(consensus)<OrigSubStrPool.getStrCount(revcom_consensus)){
				consensus = revcom_consensus;
			}
			this.CONSENSUS = consensus;
			
			
			// output the name of the motif, and the consensus sequence
			String motif_title = FullBarcode.getFullBarcode()+"-"+BarcodeTfNameTable.getTfName(FullBarcode);
			int con_cnt = (int)SubStrPool.getStrCount(CONSENSUS);
			outPFM(motif_title+"\n");
			outPFM(WIDTH+"-width   consensus sequence: "+CONSENSUS+"\t"+con_cnt+"\n");
			outPFM(WIDTH+"-width reverse complemetary: "+SubStrTool.getRevCom(CONSENSUS)+"\t"+con_cnt+"\n\n");
			
			// output the averaged difference between sequence and its reverse complementary
			outSeqBias(motif_title,OrigSubStrPool);
			
			//Calculate and output the motif; also the binding site
			calculateMotif(consensus);

			outSubStrDis(motif_title, SubStrPool);
			
			// output SubStrCount-HamDis data
			outHamDis(motif_title);
			
			// output bind site position distribution
			outBindSitePosDis();
			
			// output background distribution
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("###.###");
			
			outPFM("Background Distribution:\n");
			for(int i=0; i<4; i++){
				outPFM(df.format(BackDis[i])+"\t");
			}
			outPFM("\n\n");
			
//			String[] topseqs = BindSitePool.getTopSeqs(2);
//			if(topseqs!=null){
//				int num0 = (int)BindSitePool.getStrCount(topseqs[0]);
//				int num1 = (int)BindSitePool.getStrCount(topseqs[1]);
//				
//				outPFM("Top two sequences:\n");
//				if(num0>=num1){
//					outPFM(topseqs[0]+"\t"+num0+"\n");
//					outPFM(topseqs[1]+"\t"+num1+"\n");
//				}else{
//					outPFM(topseqs[1]+"\t"+num1+"\n");
//					outPFM(topseqs[0]+"\t"+num0+"\n");
//				}
//			}
			
			closeDataBuffers();
			
			return this;
		}catch(IOException e){
			e.printStackTrace();
		}
		
		return null;
	}
	
	public MonoFileHandler firstMotifProcess(boolean SKIP_MODE, Folder WidthFolder, BufferedWriter OutputWriter) {
		try{
			cleanseAllPools();
			
			this.WidthFolder = WidthFolder;
			this.logWriter = OutputWriter;
			
			if(IsProcessed){
				System.out.println("This data file has already been succefully processed ONCE.\n");
				return null;
			}
			
			// check the parameters
			if(!checkParas()){
				System.out.println("Input parameters are not correct, can not proceed!");
				return null;
			}
			
			BufferedReader SeqFileReader = new BufferedReader(new FileReader(new File(fileName)));
			
			String fullbarcode = FullBarcode.getFullBarcode();
			if(fullbarcode == null){
				return null;
			}
			
			// if the fullbarcode data files already exists, then we stop processing 
			if(SKIP_MODE){
				if(checkDataFiles(fullbarcode)){
					SeqFileReader.close();
					IsProcessed = true;
					return null;
				}
			}
			
			//read in the data and count the substring and so on
			String s = null;
			SeqNum = 0;
			SeqFileReader.readLine();  // read the first line of the sequence file
			while((s=SeqFileReader.readLine())!=null) {
				if(InputPool.putString(s)){
					SeqNum++;
				}
			}
			SeqFileReader.close();
			
			MonoFileHandler res = process(SKIP_MODE); 
			
			if(res!=null){
				IsProcessed = true;
				return res;
			}else{
				return null;				
			}
			 
		}catch(IOException e){
			e.printStackTrace();
		}
		
		return null;
	}
	
	/*
	 * This method not only finds a first motif from the data
	 * but also tries to find the second motif from the left data
	 * Here we assume everything goes well with the first motif discovery task 
	 */
	public MonoFileHandler secondMotifProcess(boolean SKIP_MODE, Folder WidthFolder, BufferedWriter OutputWriter){
		
		if(!IsProcessed){
			System.out.println("This data file has not been processed yet.\n");
			return null;
		}
		
		cleanseAllPools();
		
		this.WidthFolder = WidthFolder;
		this.logWriter = OutputWriter;
		
		String fullbarcode = FullBarcode.getFullBarcode();
		
		// if the fullbarcode data files already exists, then we stop processing 
		if(SKIP_MODE){
			if(checkDataFiles(fullbarcode)){
				return null;
			}
		}

		// Construct a sequence pool which contains all one base mutations of the consensus
		SeqPool ConsensusPool = new SeqPool(WIDTH);
		char[] tmpConsensus = null;
		for(int pos=0; pos<WIDTH; pos++){
			tmpConsensus = CONSENSUS.toCharArray();
			for(int j=0; j<4; j++){
				tmpConsensus[pos] = SubStrTool.Index2Base(j);
				ConsensusPool.putString(new String(tmpConsensus));
			}
		}
		
		try{
			BufferedReader SeqFileReader = new BufferedReader(new FileReader(new File(fileName)));
			//read in the data and count the substring and so on
			String s = null;
			SeqNum = 0;
			while((s=SeqFileReader.readLine())!=null) {
				if(InputPool.tool.isLegal(s) && !containSubstrs(s, ConsensusPool)){
					InputPool.putString(s);
					SeqNum++;
				}
			}
			
			return process(SKIP_MODE);
		}catch(IOException e){
			e.printStackTrace();
		}
		
		return null;
	}
	
	/*
	 * Check if the given string contains any substring in the given set   
	 */
	public boolean containSubstrs(String seq, SeqPool substrs) {
		int SeqLength = seq.length();
		int SubStrLen = substrs.tool.getLength();
		
		if(SeqLength < SubStrLen || seq==null || substrs.getTotalSeqNum()==0){
			return false;
		}
		
		boolean res = false;
		String tmp, tmpRevCom;
		for(int i=0; i<SeqLength-SubStrLen+1; i++){
			tmp = seq.substring(i,i+SubStrLen);
			tmpRevCom = substrs.tool.getRevCom(tmp);
			
			res = res || substrs.contains(tmp) || substrs.contains(tmpRevCom);
			if(res){
				return true;
			}
		}
		
		return false;
	}
	
	public void cleanseAllPools(){
		InputPool.clear();
		BindSites.clear();
	    OrigSubStrPool.clear();
	    SubStrPool.clear();
	    BindSitePool.clear();
	}

	/*
	 * this method break the input sequence into w-width substrings
	 * and count the occurrence of each substring
	 * meanwhile it also count to the background distribution
	 */
	public int handleLine(String str, double in_cnt) throws IOException{
		
		if(!InputPool.tool.isLegal(str)){
			System.out.println("Error! The input sequence is illegal. "+str);
			return -1;
		}

		// store the index of each substring
		long[] indexes = new long[SeqLen-WIDTH+1];
		long index = SubStrTool.Seq2Index(str.substring(0, WIDTH));
		indexes[0] = index;  
		for(int i=WIDTH; i<SeqLen; i++){
			index = ((index<<2) & mask) + SubStrTool.Base2Index(str.charAt(i));
			indexes[i-WIDTH+1] = index;
		}
		
		// count each substring
		Arrays.sort(indexes);
		index = -1;
		for(int i=0; i<indexes.length; i++){
			if(index != indexes[i]){     //here we exclude identical substrings
				countSubStr(indexes[i], in_cnt);
				index = indexes[i];
			}
		}
//		System.out.println();
		return 0;
	}
	
	/*
	 * Count one substring
	 */
	public void countSubStr(long index, double cnt){
		OrigSubStrPool.putString(index, cnt);
		SubStrPool.putString(index, cnt);
		
		long RevComInd = SubStrTool.getRevCom(index); 
		// the palindrome needs to be considered separately
		if(RevComInd != index){
			SubStrPool.putString(RevComInd, cnt);
		}
		
	}
	
	
	/*
	 *  find the binding sites on each sequence and construct the initial motif
	 */
	public void calculateMotif(String consensus) {
		
		int[][] hamdis = new int[2][SeqLen-WIDTH+1];
		
		for(String s : InputPool.getAllSeqs()){
			
			int BindSiteHamDis = 1000;
			
			String tmpSite=null, tmpRevCom=null;
			int tmpHamDis, RevcomHamDis;
			
			//find the binding site on the given sequence
			for(int j=0; j<SeqLen-WIDTH+1; j++){
				
				tmpSite = s.substring(j, j+WIDTH);
				tmpRevCom = SubStrTool.getRevCom(tmpSite);
				
				tmpHamDis = SubStrTool.CalHamDis(consensus, tmpSite);
				RevcomHamDis = SubStrTool.CalHamDis(consensus, tmpRevCom);
				
				hamdis[0][j] = tmpHamDis;
				hamdis[1][j] = RevcomHamDis;
				
				if(BindSiteHamDis > tmpHamDis ){
					BindSiteHamDis = tmpHamDis;
				}
				
				if(BindSiteHamDis > RevcomHamDis){
					BindSiteHamDis = RevcomHamDis;
				}
			}
			
			double str_num = InputPool.getStrCount(s);
			
			int PosNum = 0;
			for(int i=0; i<SeqLen-WIDTH+1; i++){
				if(BindSiteHamDis == hamdis[0][i]){
					PosNum ++;
				}
				if(BindSiteHamDis == hamdis[1][i]){
					PosNum ++;
				}
			}
			
//			System.out.println("BindsiteHam: "+BindSiteHamDis+"PosNum: "+PosNum);
			
			// add binding sites to position distribution
			// binding sites with the same Hamming distance are supposed to have the same amount
			for(int i=0; i<SeqLen-WIDTH+1; i++){
				if(BindSiteHamDis == hamdis[0][i] && BindSiteHamDis < HamDisCutOff){
					BindSitePosDis[0][i] += str_num/PosNum;
					BindSitePool.putString(s.substring(i,i+WIDTH), str_num/PosNum);
					BindSites.putString(s.substring(i,i+WIDTH), str_num/PosNum, BindSiteHamDis);
				}else if(BindSiteHamDis == hamdis[0][i]){
					BindSites.putString(s.substring(i,i+WIDTH), str_num/PosNum, BindSiteHamDis);
				}
				
				if(BindSiteHamDis == hamdis[1][i] && BindSiteHamDis < HamDisCutOff){
					BindSitePosDis[1][i] += str_num/PosNum;
					BindSitePool.putString(SubStrTool.getRevCom(s.substring(i,i+WIDTH)), str_num/PosNum);
					BindSites.putString(s.substring(i,i+WIDTH), str_num/PosNum, BindSiteHamDis);
				}else if(BindSiteHamDis == hamdis[1][i]){
					BindSites.putString(s.substring(i,i+WIDTH), str_num/PosNum, BindSiteHamDis);
				}
			}
		}
		
		// note that the calculation of alignment matrix is different from Hamming distance based model
		char[] tmpConsensus = null;
		for(int pos=0; pos<WIDTH; pos++){
			tmpConsensus = consensus.toCharArray();
			for(int j=0; j<4; j++){
				tmpConsensus[pos] = SubStrTool.Index2Base(j);
				motif[j][pos] = BindSitePool.getStrCount(new String(tmpConsensus));
			}
		}
		
		writeMotifFile();
	}
	
	/*
	 *  find the binding sites on each sequence and construct the initial motif
	 */
	public void calHamDisMotif(String consensus) {
		
		int[][] hamdis = new int[2][SeqLen-WIDTH+1];
		
		for(String s : InputPool.getAllSeqs()){
			
			int BindSiteHamDis = 1000;
			
			String tmpSite=null, tmpRevCom=null;
			int tmpHamDis, RevcomHamDis;
			
			//find the binding site on the given sequence
			for(int j=0; j<SeqLen-WIDTH+1; j++){
				
				tmpSite = s.substring(j, j+WIDTH);
				tmpRevCom = SubStrTool.getRevCom(tmpSite);
				
				tmpHamDis = SubStrTool.CalHamDis(consensus, tmpSite);
				RevcomHamDis = SubStrTool.CalHamDis(consensus, tmpRevCom);
				
				hamdis[0][j] = tmpHamDis;
				hamdis[1][j] = RevcomHamDis;
				
				if(BindSiteHamDis > tmpHamDis ){
					BindSiteHamDis = tmpHamDis;
				}
				
				if(BindSiteHamDis > RevcomHamDis){
					BindSiteHamDis = RevcomHamDis;
				}
			}
			
			double str_num = InputPool.getStrCount(s);
			
			int PosNum = 0;
			for(int i=0; i<SeqLen-WIDTH+1; i++){
				if(BindSiteHamDis == hamdis[0][i]){
					PosNum ++;
				}
				if(BindSiteHamDis == hamdis[1][i]){
					PosNum ++;
				}
			}
			
			// add binding sites to position distribution
			// binding sites with the same Hamming distance are supposed to have the same amount
			for(int i=0; i<SeqLen-WIDTH+1; i++){
				if(BindSiteHamDis == hamdis[0][i] && BindSiteHamDis < HamDisCutOff){
					BindSitePosDis[0][i] += str_num/PosNum;
					BindSitePool.putString(s.substring(i,i+WIDTH), str_num/PosNum);
					BindSites.putString(s.substring(i,i+WIDTH), str_num/PosNum, BindSiteHamDis);
				}else if(BindSiteHamDis == hamdis[0][i]){
					BindSites.putString(s.substring(i,i+WIDTH), str_num/PosNum, BindSiteHamDis);
				}
				
				if(BindSiteHamDis == hamdis[1][i] && BindSiteHamDis < HamDisCutOff){
					BindSitePosDis[1][i] += str_num/PosNum;
					BindSitePool.putString(SubStrTool.getRevCom(s.substring(i,i+WIDTH)), str_num/PosNum);
					BindSites.putString(s.substring(i,i+WIDTH), str_num/PosNum, BindSiteHamDis);
				}else if(BindSiteHamDis == hamdis[1][i]){
					BindSites.putString(s.substring(i,i+WIDTH), str_num/PosNum, BindSiteHamDis);
				}
			}
		}
		
		// Hamming distance based model
		char[] tmpSeq = null;
		int tmpBase;
		for(String substr : BindSitePool.getAllSeqs()){
			tmpSeq = substr.toCharArray();
			for(int pos=0; pos<WIDTH; pos++){
				tmpBase = SubStrTool.Base2Index(tmpSeq[pos]);
				motif[tmpBase][pos] += BindSitePool.getStrCount(substr);
			}
		}
		
		writeMotifFile();
	}
	
	public void writeMotifFile() {

//		DisplayMotif();
		this.outputMotif("Alignment Matrix");
		
		//calculate the frequency matrix and background distribution
		norMotifCount(BackDis);
		
//		DisplayMotif();
		this.outputMotif("Frequency Matrix");
		//store the frequency matrix
		for(int i=0; i<4; i++){
			for(int j=0; j<WIDTH; j++){
				motif_pfm[i][j] = motif[i][j];  
			}
		}

		//calculate the information content based weight matrix
		for(int i=0; i<4; i++){
			for(int j=0; j<WIDTH; j++){
				motif[i][j] = Math.log(motif[i][j]/BackDis[i])/Math.log(2); // note that BackDis has already been 
				                                                            // calculated in NorMotifCount();
			}
		}
		this.outputMotif("Information content-based weight matrix");
		
		//calcluate the the final motif for logo
		for(int j=0; j<WIDTH; j++){
			double sum = 0;
			for(int i=0; i<4; i++){
				motif[i][j] = motif[i][j]*motif_pfm[i][j];
				sum += motif[i][j];
			}
			for(int k=0; k<4; k++){
				motif[k][j] = motif_pfm[k][j] * sum;
			}
		}
		this.outputMotif("Final Motif for logo");
	}
	
	/*
	 * Normalize Alignment Matrix
	 */ 
	public void norMotifCount(double[] BackgroundDis){
		// normalize background distribution
		BackDis = BackgroundDis;
		
		// normalize motif count matrix
		double[] sum = new double[WIDTH];
		for(int i=0; i<WIDTH; i++){
			for(int j=0; j<4; j++){
				sum[i] += motif[j][i];
			}
			sum[i] = sum[i]+NorConstant;
		}
		for(int i=0; i<WIDTH; i++){
			for(int j=0; j<4; j++){
				motif[j][i] = (motif[j][i]+BackDis[j]*NorConstant) / sum[i];
			}
		}
	}
	
	/*
	 * Calculate the probability of a w-width sequence in log scale
	 */
	public double calProbability(double[][] pfm, int seqInd) {

		int MASK = 3;
		double probability = 0;

		int tmp = (seqInd & MASK);
		probability += Math.log(pfm[tmp][WIDTH-1]);
		
		for(int i=1; i<WIDTH; i++){
			seqInd = (seqInd>>2);
			tmp = (seqInd & MASK);
			probability += Math.log(pfm[tmp][WIDTH-i-1]);
		}
		
		return probability;
	}


	/*
	 * Calculate the expected number of a w-width sequence
	 */
	public int calExpSubStrCount() {
		long totalCount = mask+1;
		return (int)(SeqNum*(SeqLen-WIDTH+1)/10/totalCount);
	}

	// the first line is the title
	public void outSeqBias(String title, SeqPool pool) {
		try{
			//header
			if(title.charAt(title.length()-1)=='\n'){
				out_seqbias.write(title);
			}else{
				out_seqbias.write(title+"\n");
			}
			
			//body
			int cutoff = (ExpSubstrCount>5)?ExpSubstrCount:5;  //substr lower than cutoff will not be considered
			
			String revcom;
			double seq_cnt, revcom_cnt;
			for(String s : pool.getAllSeqs()){
				revcom = SubStrTool.getRevCom(s);
				seq_cnt = pool.getStrCount(s);
				revcom_cnt = pool.getStrCount(revcom);
				
				if(seq_cnt>cutoff || revcom_cnt>cutoff){
					out_seqbias.write(seq_cnt+"\t"+revcom_cnt+"\n");
				}
			}
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * output data for SubStrCount-HamDis figure
	 */
	public void outHamDis(String title){		
		try{
			// header
			if(title.charAt(title.length()-1)=='\n'){
				out_hamdis.write(title);
			}else{
				out_hamdis.write(title+"\n");
			}

			DecimalFormat df = new DecimalFormat();
			df.applyPattern("###.###");
			
			int cutoff = (ExpSubstrCount>3)?ExpSubstrCount:3;
			
			BindSiteProperty bsp;
			for(String seq : BindSites.pool.keySet()){
				bsp = BindSites.pool.get(seq);
				
				if(bsp.Num<cutoff){
					continue;
				}
				
				// Sequence with more Hamming distance than its reverse complement is labeled with "1"  
				if(SubStrTool.CalHamDis(seq, this.CONSENSUS)>bsp.HamDis){
					out_hamdis.write(1 + "\t" + df.format(bsp.Num) + "\t" + bsp.HamDis + "\t" + bsp.index + "\n");
				}else{
					out_hamdis.write(0 + "\t" + df.format(bsp.Num) + "\t" + bsp.HamDis + "\t" + bsp.index + "\n");
				}
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	
	/*
	 * Output the raw w-width substring distribution to the files
	 * NOTE that one seq and its reverse complement should be the same count
	 */
	public void outSubStrDis(String title, SeqPool pool) {
		try{
			// header
			if(title.charAt(title.length()-1)=='\n'){
				out_rawcount.write(title);
			}else{
				out_rawcount.write(title+"\n");
			}
			
			// data , note that the one seq and its reverse complementary seq should be the same count
			int cutoff = (ExpSubstrCount>3)?ExpSubstrCount:3;
			int cnt;
			for(String s : pool.getAllSeqs()){
				cnt = (int)pool.getStrCount(s);
				
				if(cnt>cutoff){
					out_rawcount.write(SubStrTool.Seq2Index(s)+"\t"+cnt+"\n");
				}
			}
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	
	public void outBindSitePosDis() {
		try{
			out_posdis.write(SeqNum+"\n");
			for(double[] posdis : BindSitePosDis){
				for(int i=0; i<posdis.length; i++){
					out_posdis.write(""+(int)posdis[i]);
					if(i!=posdis.length-1){
						out_posdis.write("\t");
					}else{
						out_posdis.write("\n");
					}
				}
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void outPFM(String str) {
		try{
			out_motif.write(str);
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * write the motif into file
	 */
	public void outputMotif(String title){
		try{
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("###.###");
			
			out_motif.write(title+"\n");
			
			for(int i=0; i<4; i++){
				out_motif.write(SubStrTool.Index2Base(i)+"\t");
				for(int j=0; j<WIDTH; j++){
					out_motif.write(df.format(motif[i][j])+"\t");
				}
				out_motif.write("\n");
			}
			out_motif.write("\n");

		}catch(IOException e){
			e.printStackTrace();
		}		
	}
	
	/*
	 * close all buffers
	 */
	public void closeDataBuffers() {
		try{
			out_hamdis.close();
			out_posdis.close();
			out_seqbias.close();
			out_motif.close();
			out_rawcount.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	/*
	 * check the existences of all data files
	 */
	public boolean checkDataFiles(String fullbarcode) {
		boolean res = true;
		res = res && new File(WidthFolder.dir_hamdis+fullbarcode+".dat").exists();
		res = res && new File(WidthFolder.dir_posdis+fullbarcode+".dis").exists();
		res = res && new File(WidthFolder.dir_seqbias+fullbarcode+".bias").exists();
		res = res && new File(WidthFolder.dir_motif+fullbarcode+".pwm").exists();
		res = res && new File(WidthFolder.dir_rawcount+fullbarcode+".cnt").exists();
		return res;
	}
	
	/*
	 * delete all generated files
	 */
	public void deleteDataFiles(String fullbarcode) {
		new File(WidthFolder.dir_hamdis+fullbarcode+".dat").delete();
		new File(WidthFolder.dir_posdis+fullbarcode+".dis").delete();
		new File(WidthFolder.dir_seqbias+fullbarcode+".bias").delete();
		new File(WidthFolder.dir_motif+fullbarcode+".pwm").delete();
		new File(WidthFolder.dir_rawcount+fullbarcode+".cnt").delete();
	}
	
	
	/*
	 * display the motif matrix
	 */
	public void displayMotif(){
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("###.###");
		
		for(int i=0; i<4; i++){
			for(int j=0; j<WIDTH; j++){
				System.out.print(df.format(motif[i][j])+" ");
			}
			System.out.println();
		}
		System.out.println();
	}
	
	/*
	 * check the parameters so that the program work properly
	 */
	public boolean checkParas(){
		if(this.WIDTH<5 || WIDTH>SeqLen){
			System.out.println("Width is "+WIDTH+", out of range 5-"+SeqLen+"!");
			return false;
		}
		
		if(HamDisCutOff<0 || HamDisCutOff > SeqLen){
			System.out.println("HamDisCutOff is "+HamDisCutOff+". Please check it again.");
			return false;
		}
		
		if(SeqLen<0){
			System.out.println("SeqLen is "+SeqLen+". Please check it again.");
			return false;
		}
		if(BarcodeTfNameTable==null){
			System.out.println("FullBarcode-TF table is null, please check it again!");
			return false;
		}
		if(logWriter==null){
			System.out.println("OutputWriter is null, please check it again!");
			return false;
		}
		if(!new File(fileName).exists()){
			System.out.println("Input file "+fileName+" does not exist!");
			return false;
		}
//		if(!new File(dir_bindsite).exists()){
//			System.out.println("Input Directory "+dir_bindsite+" does not exist!");
//			return false;
//		}
		if(!new File(WidthFolder.dir_hamdis).exists()){
			System.out.println("Input Directory "+WidthFolder.dir_hamdis+" does not exist!");
			return false;
		}
		if(BackDis==null){
			System.out.println("Background distribution is null!");
			return false;
		}else if(BackDis.length!=4){
			System.out.println("Length of background distribution: "+BackDis.length+". Not 4!");
			return false;
		}else{
			double sum = 0;
			for(int i=0; i<BackDis.length; i++){
				sum += BackDis[i];
			}
			if(sum!=1){
				System.out.println("Background probability does not sum to 1.");
				return false;
			}
		}
		
//		System.out.println("Input parameters OK! Start Processing.....");
		return true;
	}
	
	class BindSiteList{
		
		private HashMap<String, BindSiteProperty> pool;
		
		BindSiteList(int capacity) {
			pool = new HashMap<String, BindSiteProperty>(capacity);
		}
		
		void putString(String str, double cnt, int HamDis) {
			if(pool.containsKey(str)){
				pool.get(str).Num += cnt;
			}else{
				pool.put(str, new BindSiteProperty(cnt, HamDis, SubStrTool.Seq2Index(str)));
			}
		}
		
		HashMap<String, BindSiteProperty> getList() {
			return pool;
		}
		
		void clear() {
			pool.clear();
		}
		
	}
	
	class BindSiteProperty{
		double Num;
		int HamDis;
		long index;
		
		BindSiteProperty(double Num, int HamDis, long index) {
			this.Num = Num;
			this.HamDis = HamDis;
			this.index = index;
		}
	}
}

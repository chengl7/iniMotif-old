package MultiNominal_1;

import java.util.*;

/*
 * this class use a Hashtable to store a pool of DNA sequences
 * the sequences needs to be sorted first
 */

public class SeqPool {
	private HashMap<String, MyInt> pool;
	public SeqAnalyzer tool;
	private double SeqNum;
	
	public SeqPool(int SeqLen){
		pool = new HashMap<String, MyInt>(200000);
		tool = new SeqAnalyzer(SeqLen);
		SeqNum = 0;
	}

	/*
	 * insert one string to the pool
	 */
	public boolean putString(String seq) {
		
		if(!tool.isLegal(seq)){
			return false;
		}		

		if(pool.containsKey(seq)){
			pool.get(seq).val++;
		}else{
			pool.put(seq, new MyInt(1));
		}
		
		SeqNum++;
		return true;
	}
	
	/*
	 * insert strings to the pool
	 */
	public boolean putString(String seq, double seq_num) {

		if(!tool.isLegal(seq)){
			return false;
		}

		if(pool.containsKey(seq)){
			pool.get(seq).val += seq_num;
		}else{
			pool.put(seq, new MyInt(seq_num));
		}
		
		SeqNum += seq_num;
		
		return true;
	}

	/*
	 * insert strings to the pool
	 */
	public boolean putString(long seq_ind, double seq_num) {

		if(!tool.isLegal(seq_ind)){
			return false;
		}
		
		putString(tool.Index2Seq(seq_ind), seq_num);		
		return true;
		
	}

	/*
	 * get the consensus sequence with the highest count
	 */
	public String getConsensus() {
		String consensus = null;
		
		if (pool.size() == 0) {
			return null;
		}
		
		int tmpValue=-1, value=-1;
		for(String key: pool.keySet()){
			tmpValue = (int)pool.get(key).val;
			if(tmpValue > value){
				consensus = key;
				value = tmpValue;
			}
		}
		
		return consensus;
	}
	
	/*
	 * get the top "SeqNum" sequences
	 */
	public String[] getTopSeqs(int SeqNum) {
		
		if (pool.size() == 0) {
			return null;
		}
		
		if(SeqNum > pool.size()){
			return null;
		}
		
		String[] topSeqs = new String[SeqNum];
		double[] topCnts = new double[SeqNum];
		
		double minVal=-1;
		
		int i = 0;
		for(String key: pool.keySet()){
			if(i==SeqNum){
				Arrays.sort(topCnts);
				minVal = topCnts[0];
			}
			
			if(i<SeqNum){
				topSeqs[i] = key;
				topCnts[i] = pool.get(key).val;
			}else if(pool.get(key).val > minVal){
				for(int j=0; j<SeqNum; j++){
					if(pool.get(topSeqs[j]).val == minVal){
						topSeqs[j] = key;
						topCnts[j] = pool.get(key).val;
						break;
					}
				}
				Arrays.sort(topCnts);
				minVal = topCnts[0];
			}
			
			i++;
		}
		
		return topSeqs;
	}
	
	
	/*
	 * extract sequences in the pool
	 */
	public Set<String> getAllSeqs() {
		return pool.keySet();
	}
	
	
	/*
	 * get the count of a string
	 */
	public double getStrCount(String str) {
		if(!tool.isLegal(str)){
			return -1;
		}
		
		if(!pool.containsKey(str)){
			return 0;
		}else{
			return pool.get(str).val;
		}
	}
	
	/*
	 * get the count of a string
	 */
	public double getStrCount(int str_ind) {
		if(!tool.isLegal(str_ind)){
			return -1;
		}
		
		return getStrCount(tool.Index2Seq(str_ind));
	}
	
	public double getUniqueSeqPortion() {
		double res = pool.size();
		return res/SeqNum;
	}
	
	/*
	 * remove a string from the pool
	 */
	public boolean rmSeq(String seq) {
		if(pool.containsKey(seq)){
			SeqNum -= pool.get(seq).val;
			pool.remove(seq);
			return true;
		}else{
			return false;
		}
	}
	
	public HashMap<String, MyInt> getPool() {
		return pool;
	}
	
	// clear hash map
	public void clear() {
		pool.clear();
		SeqNum = 0;
	}
	
	public double getTotalSeqNum() {
		return SeqNum;
	}
	
	public boolean contains(String seq){
		return pool.containsKey(seq);
	}
	
	// display the sequence pool
	public void display() {
		for(String s : pool.keySet()){
			System.out.println(s+"\t"+pool.get(s).val);
		}
		System.out.println();
	}

	class MyInt {
		double val;

		MyInt(double val) {
			this.val = val;
		}
	}
	
}

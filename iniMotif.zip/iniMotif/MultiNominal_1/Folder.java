package MultiNominal_1;

import java.io.*;

public class Folder {

	public String dir_hamdis;
	public String dir_posdis;
	public String dir_seqbias;
	public String dir_motif;
	public String dir_rawcount;
	
	public Folder(String WIDTH_DIR){
		InitialMotif.rmSuffix(WIDTH_DIR);
		
		dir_hamdis = WIDTH_DIR+"/SubStrDis-HamDis/";
		dir_posdis = WIDTH_DIR+"/BindSitePosDis/";
		dir_seqbias = WIDTH_DIR+"/SeqBias/";
		dir_motif = WIDTH_DIR+"/motif/";
		dir_rawcount = WIDTH_DIR+"/SubStrDis/";

		new File(dir_hamdis).mkdirs();
		new File(dir_posdis).mkdirs();
		new File(dir_seqbias).mkdirs();
		new File(dir_motif).mkdirs();
		new File(dir_rawcount).mkdirs();
	}

}
